These are CGO bindings for libusb, created and tested on Linux.

They used to be part of go-mtpfs, a FUSE filesystem for mounting MTP
devices on Linux.


DISCLAIMER

This is not an official Google product.
